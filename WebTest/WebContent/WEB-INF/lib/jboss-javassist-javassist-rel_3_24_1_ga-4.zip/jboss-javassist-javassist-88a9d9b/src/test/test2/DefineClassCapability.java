/*
 * This is used as a capability for running CtClass#toClass().
 */
package test2;

public class DefineClassCapability {
}

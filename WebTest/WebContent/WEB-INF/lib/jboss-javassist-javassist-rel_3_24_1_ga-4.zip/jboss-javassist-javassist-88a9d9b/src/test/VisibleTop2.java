@SuppressWarnings("unused")
public class VisibleTop2 {
    public int pub;
    protected int pro;
    private int pri;
    int pack;
}
